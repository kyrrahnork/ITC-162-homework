package slorah.com.tictactoe;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class TictacactivityActivity extends AppCompatActivity {

    private Button b00, b01, b02, b10, b11, b12, b20, b21, b22;
    private TextView info;
    private Button start;
    private int turn;
    private int turnCounter = 1;

    private SharedPreferences savedValues;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tictacactivity);

        b00 = (Button) findViewById(R.id.button00);
        b01 = (Button) findViewById(R.id.button01);
        b02 = (Button) findViewById(R.id.button02);
        b10 = (Button) findViewById(R.id.button10);
        b11 = (Button) findViewById(R.id.button11);
        b12 = (Button) findViewById(R.id.button12);
        b20 = (Button) findViewById(R.id.button20);
        b21 = (Button) findViewById(R.id.button21);
        b22 = (Button) findViewById(R.id.button22);
        info = (TextView) findViewById(R.id.winner);
        start = (Button) findViewById(R.id.start);

        turn = 1;

        start.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                clearBoard();
            }
        });
        info.setText("Player X's turn");
        b00.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (b00.getText().toString().equals("")) {
                    if (turn == 1) {
                        info.setText("Player O's turn");
                        turn = 2;
                        b00.setText("X");
                    } else if (turn == 2) {
                        info.setText("Player X's turn");
                        turn = 1;
                        b00.setText("O");
                    }
                }
                turnCounter++;
                endGame();
            }
        });
        b01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (b01.getText().toString().equals("")) {
                    if (turn == 1) {
                        info.setText("Player O's turn");
                        turn = 2;
                        b01.setText("X");
                    } else if (turn == 2) {
                        info.setText("Player X's turn");
                        turn = 1;
                        b01.setText("O");
                    }
                }
                turnCounter++;
                endGame();
            }
        });
        b02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (b02.getText().toString().equals("")) {
                    if (turn == 1) {
                        info.setText("Player O's turn");
                        turn = 2;
                        b02.setText("X");
                    } else if (turn == 2) {
                        info.setText("Player X's turn");
                        turn = 1;
                        b02.setText("O");
                    }
                }
                turnCounter++;
                endGame();
            }
        });
        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (b10.getText().toString().equals("")) {
                    if (turn == 1) {
                        info.setText("Player O's turn");
                        turn = 2;
                        b10.setText("X");
                    } else if (turn == 2) {
                        info.setText("Player X's turn");
                        turn = 1;
                        b10.setText("O");
                    }
                }
                turnCounter++;
                endGame();
            }
        });
        b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (b11.getText().toString().equals("")) {
                    if (turn == 1) {
                        info.setText("Player O's turn");
                        turn = 2;
                        b11.setText("X");
                    } else if (turn == 2) {
                        info.setText("Player X's turn");
                        turn = 1;
                        b11.setText("O");
                    }
                }
                turnCounter++;
                endGame();
            }
        });
        b12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (b12.getText().toString().equals("")) {
                    if (turn == 1) {
                        info.setText("Player O's turn");
                        turn = 2;
                        b12.setText("X");
                    } else if (turn == 2) {
                        info.setText("Player X's turn");
                        turn = 1;
                        b12.setText("O");
                    }
                }
                turnCounter++;
                endGame();
            }
        });
        b20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (b20.getText().toString().equals("")) {
                    if (turn == 1) {
                        info.setText("Player O's turn");
                        turn = 2;
                        b20.setText("X");
                    } else if (turn == 2) {
                        info.setText("Player X's turn");
                        turn = 1;
                        b20.setText("O");
                    }
                }
                turnCounter++;
                endGame();
            }
        });
        b21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (b21.getText().toString().equals("")) {
                    if (turn == 1) {
                        info.setText("Player O's turn");
                        turn = 2;
                        b21.setText("X");
                    } else if (turn == 2) {
                        info.setText("Player X's turn");
                        turn = 1;
                        b21.setText("O");
                    }
                }
                turnCounter++;
                endGame();
            }
        });
        b22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (b22.getText().toString().equals("")) {
                    if (turn == 1) {
                        info.setText("Player O's turn");
                        turn = 2;
                        b22.setText("X");
                    } else if (turn == 2) {
                        info.setText("Player X's turn");
                        turn = 1;
                        b22.setText("O");
                    }
                }
                turnCounter++;
                endGame();
            }
        });
        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);
    }
    /*
    String txtInfo = info.getText().toString();
    String b1 = b00.getText().toString();
    String b2 = b01.getText().toString();
    String b3 = b02.getText().toString();
    String b4 = b10.getText().toString();
    String b5 = b11.getText().toString();
    String b6 = b12.getText().toString();
    String b7 = b20.getText().toString();
    String b8 = b21.getText().toString();
    String b9 = b22.getText().toString();

    @Override
    public void onPause() {
        super.onPause();

        // Store values between instances here

        Editor editor = savedValues.edit();




        editor.putString("info", txtInfo);
        editor.putString("button1", b1);
        editor.putString("button2", b2);
        editor.putString("button3", b3);
        editor.putString("button4", b4);
        editor.putString("button5", b5);
        editor.putString("button6", b6);
        editor.putString("button7", b7);
        editor.putString("button8", b8);
        editor.putString("button9", b9);

        // Commit to storage
        editor.commit();
    }

    @Override
    public void onResume(){
        super.onResume();

        txtInfo = savedValues.getString("info", txtInfo);
        b1 = savedValues.getString("button1", b1);
        b2 = savedValues.getString("button2", b2);
        b3 = savedValues.getString("button3", b3);
        b4 = savedValues.getString("button4", b4);
        b5 = savedValues.getString("button5", b5);
        b6 = savedValues.getString("button6", b6);
        b7 = savedValues.getString("button7", b7);
        b8 = savedValues.getString("button8", b8);
        b9 = savedValues.getString("button9", b9);
    }

*/
    public void endGame() {
        String s00, s01, s02, s10, s11, s12, s20, s21, s22;
        s00 = b00.getText().toString();
        s01 = b01.getText().toString();
        s02 = b02.getText().toString();
        s10 = b10.getText().toString();
        s11 = b11.getText().toString();
        s12 = b12.getText().toString();
        s20 = b20.getText().toString();
        s21 = b21.getText().toString();
        s22 = b22.getText().toString();
        String winx = "X";
        String wino = "O";

        if (turnCounter <= 9) {
            if (s00.equals(s01) && s00.equals(s02) && (s00.equals(winx) || s00.equals(wino))) {
                info.setText("Player " + s00 + " wins!\n Try Again?");
            } else if (s10.equals(s11) && s10.equals(s12) && (s10.equals(winx) || s10.equals(wino))) {
                info.setText("Player " + s10 + " wins!\n Try Again?");
            } else if (s20.equals(s21) && s20.equals(s22) && (s20.equals(winx) || s20.equals(wino))) {
                info.setText("Player " + s20 + " wins!\n Try Again?");
            } else if (s00.equals(s10) && s00.equals(s20) && (s00.equals(winx) || s00.equals(wino))) {
                info.setText("Player " + s00 + " wins!\n Try Again?");
            } else if (s01.equals(s11) && s01.equals(s21) && (s01.equals(winx) || s01.equals(wino))) {
                info.setText("Player " + s01 + " wins!\n Try Again?");
            } else if (s02.equals(s12) && s02.equals(s22) && (s02.equals(winx) || s02.equals(wino))) {
                info.setText("Player " + s02 + " wins!\n Try Again?");
            } else if (s00.equals(s11) && s00.equals(s22) && (s00.equals(winx) || s00.equals(wino))) {
                info.setText("Player " + s00 + " wins!\n Try Again?");
            } else if (s20.equals(s11) && s20.equals(s02) && (s20.equals(winx) || s20.equals(wino))) {
                info.setText("Player " + s20 + " wins!\n Try Again?");
            }
        }else {
            info.setText("It is a draw..Restart");
        }
    }

    public void clearBoard(){
        b00.setText("");
        b01.setText("");
        b02.setText("");
        b10.setText("");
        b11.setText("");
        b12.setText("");
        b20.setText("");
        b21.setText("");
        b22.setText("");
        info.setText("Player X's turn");
        turn = 1;
        turnCounter = 1;
    }
}
