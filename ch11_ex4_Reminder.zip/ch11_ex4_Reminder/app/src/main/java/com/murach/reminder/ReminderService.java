package com.murach.reminder;

import android.app.Service;
import android.util.Log;
import android.content.Intent;
import android.os.IBinder;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by amy61 on 5/31/2017.
 */

public class ReminderService extends Service {

    private Timer timer;


    @Override
    public void onCreate(){
        Log.d("Reminder", "Service Created");
        startTimer();
    }

    @Override
    public IBinder onBind(Intent intent){
        Log.d("Reminder", "No binding for this service.");
        return null;
    }

    @Override
    public void onDestroy(){
        Log.d("Reminder", "Service Destroyed");
        stopTimer();
    }

    private void startTimer(){
        TimerTask task = new TimerTask(){
            @Override
            public void run(){
                Log.d("Reminder", "Look into the distance. It's good for your eyes!");
        }
        };
        timer = new Timer(true);
        int delay = 1000 * 5;
        int interval = 1000 * 60 * 60;
        timer.schedule(task, delay, interval);
    }
    private void stopTimer(){
        if (timer != null){
            timer.cancel();
        }
    }
}
